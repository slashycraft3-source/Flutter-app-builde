import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:provider/provider.dart';

import 'models/todo_item.dart';
import 'models/note_item.dart';
import 'models/habit_item.dart';
import 'providers/todo_provider.dart';
import 'providers/note_provider.dart';
import 'providers/habit_provider.dart';
import 'theme/app_theme.dart';
import 'screens/home_shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Hive.initFlutter();
  Hive.registerAdapter(TodoItemAdapter());
  Hive.registerAdapter(NoteItemAdapter());
  Hive.registerAdapter(HabitItemAdapter());

  final todoProvider = TodoProvider();
  final noteProvider = NoteProvider();
  final habitProvider = HabitProvider();
  await Future.wait([
    todoProvider.init(),
    noteProvider.init(),
    habitProvider.init(),
  ]);

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Colors.transparent,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

  runApp(SlashyFlowApp(
    todoProvider: todoProvider,
    noteProvider: noteProvider,
    habitProvider: habitProvider,
  ));
}

class SlashyFlowApp extends StatelessWidget {
  const SlashyFlowApp({
    super.key,
    required this.todoProvider,
    required this.noteProvider,
    required this.habitProvider,
  });

  final TodoProvider todoProvider;
  final NoteProvider noteProvider;
  final HabitProvider habitProvider;

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: todoProvider),
        ChangeNotifierProvider.value(value: noteProvider),
        ChangeNotifierProvider.value(value: habitProvider),
      ],
      child: MaterialApp(
        title: 'Slashy Flow',
        debugShowCheckedModeBanner: false,
        theme: buildAppTheme(),
        home: const HomeShell(),
      ),
    );
  }
}
