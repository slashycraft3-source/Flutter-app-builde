import 'package:hive/hive.dart';

enum Priority { low, medium, high }

class TodoItem {
  TodoItem({
    required this.id,
    required this.title,
    this.notes = '',
    this.isDone = false,
    this.priority = Priority.medium,
    this.dueDate,
    required this.createdAt,
    this.completedAt,
    this.tag = 'General',
  });

  final String id;
  String title;
  String notes;
  bool isDone;
  Priority priority;
  DateTime? dueDate;
  final DateTime createdAt;
  DateTime? completedAt;
  String tag;

  bool get isOverdue =>
      !isDone && dueDate != null && dueDate!.isBefore(DateTime.now());

  TodoItem copyWith({
    String? title,
    String? notes,
    bool? isDone,
    Priority? priority,
    DateTime? dueDate,
    bool clearDueDate = false,
    DateTime? completedAt,
    String? tag,
  }) {
    return TodoItem(
      id: id,
      title: title ?? this.title,
      notes: notes ?? this.notes,
      isDone: isDone ?? this.isDone,
      priority: priority ?? this.priority,
      dueDate: clearDueDate ? null : (dueDate ?? this.dueDate),
      createdAt: createdAt,
      completedAt: completedAt ?? this.completedAt,
      tag: tag ?? this.tag,
    );
  }
}

/// Hand-written Hive adapter — avoids requiring a build_runner codegen
/// step, so the project runs immediately after `flutter pub get`.
class TodoItemAdapter extends TypeAdapter<TodoItem> {
  @override
  final int typeId = 0;

  @override
  TodoItem read(BinaryReader reader) {
    final map = reader.readMap();
    return TodoItem(
      id: map['id'] as String,
      title: map['title'] as String,
      notes: map['notes'] as String? ?? '',
      isDone: map['isDone'] as bool? ?? false,
      priority: Priority.values[map['priority'] as int? ?? 1],
      dueDate: map['dueDate'] == null
          ? null
          : DateTime.fromMillisecondsSinceEpoch(map['dueDate'] as int),
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['createdAt'] as int),
      completedAt: map['completedAt'] == null
          ? null
          : DateTime.fromMillisecondsSinceEpoch(map['completedAt'] as int),
      tag: map['tag'] as String? ?? 'General',
    );
  }

  @override
  void write(BinaryWriter writer, TodoItem obj) {
    writer.writeMap({
      'id': obj.id,
      'title': obj.title,
      'notes': obj.notes,
      'isDone': obj.isDone,
      'priority': obj.priority.index,
      'dueDate': obj.dueDate?.millisecondsSinceEpoch,
      'createdAt': obj.createdAt.millisecondsSinceEpoch,
      'completedAt': obj.completedAt?.millisecondsSinceEpoch,
      'tag': obj.tag,
    });
  }
}
