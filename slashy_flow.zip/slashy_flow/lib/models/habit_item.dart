import 'package:hive/hive.dart';

DateTime _dayOnly(DateTime d) => DateTime(d.year, d.month, d.day);

class HabitItem {
  HabitItem({
    required this.id,
    required this.name,
    required this.createdAt,
    this.icon = 0,
    this.colorIndex = 0,
    this.targetDaysPerWeek = 7,
    Set<DateTime>? completedDays,
  }) : completedDays = completedDays ?? <DateTime>{};

  final String id;
  String name;
  final DateTime createdAt;
  int icon;
  int colorIndex;
  int targetDaysPerWeek;

  /// Day-normalized (no time component) set of completed dates.
  Set<DateTime> completedDays;

  bool isDoneOn(DateTime day) => completedDays.contains(_dayOnly(day));

  bool get isDoneToday => isDoneOn(DateTime.now());

  void toggleDay(DateTime day) {
    final d = _dayOnly(day);
    if (completedDays.contains(d)) {
      completedDays.remove(d);
    } else {
      completedDays.add(d);
    }
  }

  /// Current streak: consecutive completed days counting backward from
  /// today. If today isn't done yet, we still count backward from
  /// yesterday so a streak survives the "haven't logged today yet" gap.
  int get currentStreak {
    if (completedDays.isEmpty) return 0;
    final today = _dayOnly(DateTime.now());
    var cursor = isDoneOn(today) ? today : today.subtract(const Duration(days: 1));
    int streak = 0;
    while (isDoneOn(cursor)) {
      streak++;
      cursor = cursor.subtract(const Duration(days: 1));
    }
    return streak;
  }

  int get longestStreak {
    if (completedDays.isEmpty) return 0;
    final sorted = completedDays.toList()..sort();
    int longest = 1;
    int running = 1;
    for (var i = 1; i < sorted.length; i++) {
      final diff = sorted[i].difference(sorted[i - 1]).inDays;
      if (diff == 1) {
        running++;
      } else if (diff > 1) {
        running = 1;
      }
      if (running > longest) longest = running;
    }
    return longest;
  }

  /// Completion count within the last 7 days (for a weekly-target ring).
  int get last7DaysCount {
    final today = _dayOnly(DateTime.now());
    int count = 0;
    for (var i = 0; i < 7; i++) {
      if (isDoneOn(today.subtract(Duration(days: i)))) count++;
    }
    return count;
  }
}

class HabitItemAdapter extends TypeAdapter<HabitItem> {
  @override
  final int typeId = 2;

  @override
  HabitItem read(BinaryReader reader) {
    final map = reader.readMap();
    final rawDays = (map['completedDays'] as List).cast<int>();
    return HabitItem(
      id: map['id'] as String,
      name: map['name'] as String,
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['createdAt'] as int),
      icon: map['icon'] as int? ?? 0,
      colorIndex: map['colorIndex'] as int? ?? 0,
      targetDaysPerWeek: map['targetDaysPerWeek'] as int? ?? 7,
      completedDays: rawDays
          .map((ms) => _dayOnly(DateTime.fromMillisecondsSinceEpoch(ms)))
          .toSet(),
    );
  }

  @override
  void write(BinaryWriter writer, HabitItem obj) {
    writer.writeMap({
      'id': obj.id,
      'name': obj.name,
      'createdAt': obj.createdAt.millisecondsSinceEpoch,
      'icon': obj.icon,
      'colorIndex': obj.colorIndex,
      'targetDaysPerWeek': obj.targetDaysPerWeek,
      'completedDays':
          obj.completedDays.map((d) => d.millisecondsSinceEpoch).toList(),
    });
  }
}
