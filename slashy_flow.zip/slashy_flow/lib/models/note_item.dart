import 'package:hive/hive.dart';

class NoteItem {
  NoteItem({
    required this.id,
    required this.title,
    required this.body,
    required this.createdAt,
    required this.updatedAt,
    this.isPinned = false,
    this.colorTag = 0,
  });

  final String id;
  String title;
  String body;
  final DateTime createdAt;
  DateTime updatedAt;
  bool isPinned;

  /// Index into a small fixed palette (see NotesScreen) — keeps storage
  /// simple (an int) instead of persisting raw Color values.
  int colorTag;

  NoteItem copyWith({
    String? title,
    String? body,
    bool? isPinned,
    int? colorTag,
  }) {
    return NoteItem(
      id: id,
      title: title ?? this.title,
      body: body ?? this.body,
      createdAt: createdAt,
      updatedAt: DateTime.now(),
      isPinned: isPinned ?? this.isPinned,
      colorTag: colorTag ?? this.colorTag,
    );
  }
}

class NoteItemAdapter extends TypeAdapter<NoteItem> {
  @override
  final int typeId = 1;

  @override
  NoteItem read(BinaryReader reader) {
    final map = reader.readMap();
    return NoteItem(
      id: map['id'] as String,
      title: map['title'] as String,
      body: map['body'] as String,
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['createdAt'] as int),
      updatedAt: DateTime.fromMillisecondsSinceEpoch(map['updatedAt'] as int),
      isPinned: map['isPinned'] as bool? ?? false,
      colorTag: map['colorTag'] as int? ?? 0,
    );
  }

  @override
  void write(BinaryWriter writer, NoteItem obj) {
    writer.writeMap({
      'id': obj.id,
      'title': obj.title,
      'body': obj.body,
      'createdAt': obj.createdAt.millisecondsSinceEpoch,
      'updatedAt': obj.updatedAt.millisecondsSinceEpoch,
      'isPinned': obj.isPinned,
      'colorTag': obj.colorTag,
    });
  }
}
