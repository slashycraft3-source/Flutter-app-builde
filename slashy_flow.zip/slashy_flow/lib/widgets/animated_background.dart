import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Slow-drifting blurred color orbs over the base gradient. This is what
/// gives the glass panels something soft and colorful to refract, instead
/// of blurring flat black (which looks dead).
class AnimatedBackground extends StatefulWidget {
  const AnimatedBackground({super.key, required this.child});
  final Widget child;

  @override
  State<AnimatedBackground> createState() => _AnimatedBackgroundState();
}

class _AnimatedBackgroundState extends State<AnimatedBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 24),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Container(
      decoration: const BoxDecoration(gradient: AppGradients.background),
      child: Stack(
        children: [
          AnimatedBuilder(
            animation: _controller,
            builder: (context, _) {
              final t = _controller.value * 2 * math.pi;
              return Stack(
                children: [
                  _orb(
                    size: size.width * 0.9,
                    color: AppColors.accentA,
                    dx: size.width * 0.15 + 40 * math.sin(t),
                    dy: size.height * 0.05 + 30 * math.cos(t),
                  ),
                  _orb(
                    size: size.width * 0.8,
                    color: AppColors.accentB,
                    dx: size.width * 0.35 - 30 * math.cos(t),
                    dy: size.height * 0.55 + 40 * math.sin(t * 1.3),
                  ),
                  _orb(
                    size: size.width * 0.6,
                    color: AppColors.habitAccent,
                    dx: -size.width * 0.1 + 25 * math.sin(t * 0.7),
                    dy: size.height * 0.8 - 20 * math.cos(t * 0.9),
                  ),
                ],
              );
            },
          ),
          widget.child,
        ],
      ),
    );
  }

  Widget _orb({
    required double size,
    required Color color,
    required double dx,
    required double dy,
  }) {
    return Positioned(
      left: dx,
      top: dy,
      child: ImageFiltered(
        imageFilter: ImageFilter.blur(sigmaX: 90, sigmaY: 90),
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: color.withOpacity(0.22),
          ),
        ),
      ),
    );
  }
}
