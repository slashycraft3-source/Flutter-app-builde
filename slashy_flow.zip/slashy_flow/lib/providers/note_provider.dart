import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:uuid/uuid.dart';
import '../models/note_item.dart';

class NoteProvider extends ChangeNotifier {
  static const boxName = 'notes_box';
  late Box<NoteItem> _box;
  final _uuid = const Uuid();

  Future<void> init() async {
    _box = await Hive.openBox<NoteItem>(boxName);
  }

  List<NoteItem> all({String query = ''}) {
    var list = _box.values.toList();
    if (query.trim().isNotEmpty) {
      final q = query.toLowerCase();
      list = list
          .where((n) =>
              n.title.toLowerCase().contains(q) ||
              n.body.toLowerCase().contains(q))
          .toList();
    }
    list.sort((a, b) {
      if (a.isPinned != b.isPinned) return a.isPinned ? -1 : 1;
      return b.updatedAt.compareTo(a.updatedAt);
    });
    return list;
  }

  NoteItem create() {
    final note = NoteItem(
      id: _uuid.v4(),
      title: '',
      body: '',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
    _box.put(note.id, note);
    notifyListeners();
    return note;
  }

  void save(NoteItem note) {
    _box.put(note.id, note);
    notifyListeners();
  }

  void delete(String id) {
    _box.delete(id);
    notifyListeners();
  }

  void togglePin(String id) {
    final n = _box.get(id);
    if (n == null) return;
    _box.put(id, n.copyWith(isPinned: !n.isPinned));
    notifyListeners();
  }

  int get count => _box.length;
}
