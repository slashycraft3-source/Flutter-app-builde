import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:uuid/uuid.dart';
import '../models/habit_item.dart';

class HabitProvider extends ChangeNotifier {
  static const boxName = 'habits_box';
  late Box<HabitItem> _box;
  final _uuid = const Uuid();

  Future<void> init() async {
    _box = await Hive.openBox<HabitItem>(boxName);
  }

  List<HabitItem> get all {
    final list = _box.values.toList();
    list.sort((a, b) => b.currentStreak.compareTo(a.currentStreak));
    return list;
  }

  void add({
    required String name,
    int icon = 0,
    int colorIndex = 0,
    int targetDaysPerWeek = 7,
  }) {
    final habit = HabitItem(
      id: _uuid.v4(),
      name: name,
      createdAt: DateTime.now(),
      icon: icon,
      colorIndex: colorIndex,
      targetDaysPerWeek: targetDaysPerWeek,
    );
    _box.put(habit.id, habit);
    notifyListeners();
  }

  void toggleToday(String id) {
    final h = _box.get(id);
    if (h == null) return;
    h.toggleDay(DateTime.now());
    _box.put(id, h);
    notifyListeners();
  }

  void toggleDay(String id, DateTime day) {
    final h = _box.get(id);
    if (h == null) return;
    h.toggleDay(day);
    _box.put(id, h);
    notifyListeners();
  }

  void delete(String id) {
    _box.delete(id);
    notifyListeners();
  }

  int get bestActiveStreak =>
      all.fold(0, (max, h) => h.currentStreak > max ? h.currentStreak : max);

  int get doneTodayCount => _box.values.where((h) => h.isDoneToday).length;
}
