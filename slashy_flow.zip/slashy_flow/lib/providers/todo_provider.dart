import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:uuid/uuid.dart';
import '../models/todo_item.dart';

class TodoProvider extends ChangeNotifier {
  static const boxName = 'todos_box';
  late Box<TodoItem> _box;
  final _uuid = const Uuid();

  Future<void> init() async {
    _box = await Hive.openBox<TodoItem>(boxName);
  }

  List<TodoItem> get all => _box.values.toList()
    ..sort((a, b) {
      if (a.isDone != b.isDone) return a.isDone ? 1 : -1;
      final ad = a.dueDate ?? DateTime(2100);
      final bd = b.dueDate ?? DateTime(2100);
      return ad.compareTo(bd);
    });

  List<TodoItem> get pending => all.where((t) => !t.isDone).toList();
  List<TodoItem> get completed => all.where((t) => t.isDone).toList();

  List<String> get tags {
    final s = _box.values.map((t) => t.tag).toSet().toList();
    s.sort();
    return s;
  }

  void add({
    required String title,
    String notes = '',
    Priority priority = Priority.medium,
    DateTime? dueDate,
    String tag = 'General',
  }) {
    final item = TodoItem(
      id: _uuid.v4(),
      title: title,
      notes: notes,
      priority: priority,
      dueDate: dueDate,
      createdAt: DateTime.now(),
      tag: tag,
    );
    _box.put(item.id, item);
    notifyListeners();
  }

  void update(TodoItem item) {
    _box.put(item.id, item);
    notifyListeners();
  }

  void toggleDone(String id) {
    final item = _box.get(id);
    if (item == null) return;
    final updated = item.copyWith(
      isDone: !item.isDone,
      completedAt: !item.isDone ? DateTime.now() : null,
    );
    _box.put(id, updated);
    notifyListeners();
  }

  void delete(String id) {
    _box.delete(id);
    notifyListeners();
  }

  // --- Stats used on the dashboard ---
  int get completedTodayCount => _box.values
      .where((t) =>
          t.isDone &&
          t.completedAt != null &&
          _isSameDay(t.completedAt!, DateTime.now()))
      .length;

  int get overdueCount => _box.values.where((t) => t.isOverdue).length;

  bool _isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;
}
