import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Central design tokens for the "frosted glass, dark & techy" look.
class AppColors {
  AppColors._();

  // Deep space background — near-black with a hint of blue.
  static const bgTop = Color(0xFF0B0E17);
  static const bgBottom = Color(0xFF11162A);

  // Accent gradient — electric violet -> cyan, used sparingly for emphasis.
  static const accentA = Color(0xFF7C6CFF);
  static const accentB = Color(0xFF32D6C9);

  static const habitAccent = Color(0xFFFFB35C);
  static const noteAccent = Color(0xFF32D6C9);
  static const todoAccent = Color(0xFF7C6CFF);
  static const dangerAccent = Color(0xFFFF6B6B);

  static const textPrimary = Color(0xFFF4F5FB);
  static const textSecondary = Color(0xB3F4F5FB); // ~70% opacity
  static const textMuted = Color(0x66F4F5FB); // ~40% opacity

  // Glass surfaces — translucent white over the dark background.
  static const glassFill = Color(0x1AFFFFFF); // 10% white
  static const glassFillStrong = Color(0x29FFFFFF); // 16% white
  static const glassBorder = Color(0x33FFFFFF); // 20% white
}

class AppGradients {
  AppGradients._();

  static const background = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [AppColors.bgTop, AppColors.bgBottom],
  );

  static const accent = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [AppColors.accentA, AppColors.accentB],
  );
}

class AppRadii {
  AppRadii._();
  static const card = 24.0;
  static const chip = 16.0;
  static const sheet = 28.0;
}

ThemeData buildAppTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  final textTheme = GoogleFonts.plusJakartaSansTextTheme(base.textTheme).apply(
    bodyColor: AppColors.textPrimary,
    displayColor: AppColors.textPrimary,
  );

  return base.copyWith(
    scaffoldBackgroundColor: AppColors.bgTop,
    textTheme: textTheme,
    colorScheme: base.colorScheme.copyWith(
      primary: AppColors.accentA,
      secondary: AppColors.accentB,
      surface: AppColors.bgBottom,
      error: AppColors.dangerAccent,
    ),
    splashFactory: InkRipple.splashFactory,
    highlightColor: Colors.white.withOpacity(0.03),
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: false,
    ),
    dividerColor: AppColors.glassBorder,
    checkboxTheme: CheckboxThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
      side: const BorderSide(color: AppColors.glassBorder, width: 1.4),
    ),
  );
}
