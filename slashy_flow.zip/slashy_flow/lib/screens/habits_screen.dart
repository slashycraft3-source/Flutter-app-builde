import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/habit_item.dart';
import '../providers/habit_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_container.dart';

const _habitColors = [
  AppColors.habitAccent,
  AppColors.todoAccent,
  AppColors.noteAccent,
  AppColors.dangerAccent,
];

const _habitIcons = [
  Icons.local_fire_department_rounded,
  Icons.fitness_center_rounded,
  Icons.menu_book_rounded,
  Icons.water_drop_rounded,
  Icons.self_improvement_rounded,
  Icons.bedtime_rounded,
  Icons.code_rounded,
  Icons.eco_rounded,
];

class HabitsScreen extends StatelessWidget {
  const HabitsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final habits = context.watch<HabitProvider>();
    final list = habits.all;

    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: AppGradients.accent,
          boxShadow: [
            BoxShadow(
                color: AppColors.habitAccent.withOpacity(0.35),
                blurRadius: 20,
                offset: const Offset(0, 8)),
          ],
        ),
        child: IconButton(
          icon: const Icon(Icons.add_rounded, color: Colors.white, size: 28),
          onPressed: () => _openAddSheet(context),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
              child: Row(
                children: [
                  const Text('Habits',
                      style: TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.w800,
                          color: AppColors.textPrimary)),
                  const Spacer(),
                  Text('${habits.doneTodayCount}/${list.length} today',
                      style: const TextStyle(color: AppColors.textMuted)),
                ],
              ),
            ),
            Expanded(
              child: list.isEmpty
                  ? const Center(
                      child: Text('No habits yet — tap + to start a streak.',
                          style: TextStyle(color: AppColors.textMuted)),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(20, 8, 20, 120),
                      itemCount: list.length,
                      itemBuilder: (context, i) => _HabitCard(habit: list[i]),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  void _openAddSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const _AddHabitSheet(),
    );
  }
}

class _HabitCard extends StatelessWidget {
  const _HabitCard({required this.habit});
  final HabitItem habit;

  @override
  Widget build(BuildContext context) {
    final habits = context.read<HabitProvider>();
    final color = _habitColors[habit.colorIndex % _habitColors.length];
    final icon = _habitIcons[habit.icon % _habitIcons.length];

    return GlassContainer(
      margin: const EdgeInsets.only(bottom: 12),
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => HabitDetailScreen(habitId: habit.id)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withOpacity(0.18),
                ),
                child: Icon(icon, color: color, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(habit.name,
                        style: const TextStyle(
                            color: AppColors.textPrimary,
                            fontWeight: FontWeight.w700,
                            fontSize: 15)),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        Icon(Icons.local_fire_department_rounded,
                            color: color, size: 14),
                        const SizedBox(width: 4),
                        Text('${habit.currentStreak} day streak',
                            style: const TextStyle(
                                color: AppColors.textMuted, fontSize: 12)),
                        const SizedBox(width: 10),
                        Text('best ${habit.longestStreak}',
                            style: const TextStyle(
                                color: AppColors.textMuted, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () => habits.toggleToday(habit.id),
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: habit.isDoneToday ? color : Colors.transparent,
                    border: Border.all(
                      color: habit.isDoneToday ? color : AppColors.glassBorder,
                      width: 2,
                    ),
                  ),
                  child: Icon(
                    Icons.check_rounded,
                    color: habit.isDoneToday ? Colors.white : AppColors.textMuted,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _WeekStrip(habit: habit, color: color),
        ],
      ),
    );
  }
}

/// Last-7-days row of dots, filled if the habit was done that day.
class _WeekStrip extends StatelessWidget {
  const _WeekStrip({required this.habit, required this.color});
  final HabitItem habit;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final today = DateTime.now();
    final days = List.generate(7, (i) => today.subtract(Duration(days: 6 - i)));
    const labels = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: days.map((d) {
        final done = habit.isDoneOn(d);
        return Column(
          children: [
            Container(
              width: 26,
              height: 26,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: done ? color : AppColors.glassFill,
                border: Border.all(
                  color: done ? color : AppColors.glassBorder,
                ),
              ),
              child: done
                  ? const Icon(Icons.check, size: 14, color: Colors.white)
                  : null,
            ),
            const SizedBox(height: 4),
            Text(labels[d.weekday - 1],
                style: const TextStyle(fontSize: 10, color: AppColors.textMuted)),
          ],
        );
      }).toList(),
    );
  }
}

class _AddHabitSheet extends StatefulWidget {
  const _AddHabitSheet();

  @override
  State<_AddHabitSheet> createState() => _AddHabitSheetState();
}

class _AddHabitSheetState extends State<_AddHabitSheet> {
  final _name = TextEditingController();
  int _icon = 0;
  int _color = 0;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
        child: GlassContainer(
          borderRadius: AppRadii.sheet,
          blurSigma: 30,
          fillColor: AppColors.glassFillStrong,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('New habit',
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary)),
              const SizedBox(height: 16),
              TextField(
                controller: _name,
                autofocus: true,
                style: const TextStyle(color: AppColors.textPrimary),
                decoration: InputDecoration(
                  hintText: 'e.g. Drink water, Read, Meditate',
                  hintStyle: const TextStyle(color: AppColors.textMuted),
                  filled: true,
                  fillColor: AppColors.glassFill,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              const Text('Icon',
                  style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: List.generate(_habitIcons.length, (i) {
                  final selected = _icon == i;
                  final color = _habitColors[_color % _habitColors.length];
                  return GestureDetector(
                    onTap: () => setState(() => _icon = i),
                    child: Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: selected ? color.withOpacity(0.25) : AppColors.glassFill,
                        border: Border.all(
                          color: selected ? color : AppColors.glassBorder,
                        ),
                      ),
                      child: Icon(_habitIcons[i],
                          color: selected ? color : AppColors.textMuted),
                    ),
                  );
                }),
              ),
              const SizedBox(height: 16),
              const Text('Color',
                  style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
              const SizedBox(height: 8),
              Row(
                children: List.generate(_habitColors.length, (i) {
                  final selected = _color == i;
                  return Padding(
                    padding: const EdgeInsets.only(right: 10),
                    child: GestureDetector(
                      onTap: () => setState(() => _color = i),
                      child: Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _habitColors[i],
                          border: Border.all(
                            color: selected ? Colors.white : Colors.transparent,
                            width: 2,
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: Material(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(16),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () {
                      if (_name.text.trim().isEmpty) return;
                      context.read<HabitProvider>().add(
                            name: _name.text.trim(),
                            icon: _icon,
                            colorIndex: _color,
                          );
                      Navigator.of(context).pop();
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        gradient: AppGradients.accent,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      alignment: Alignment.center,
                      child: const Text('Start habit',
                          style: TextStyle(
                              color: Colors.white, fontWeight: FontWeight.w700)),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class HabitDetailScreen extends StatelessWidget {
  const HabitDetailScreen({super.key, required this.habitId});
  final String habitId;

  @override
  Widget build(BuildContext context) {
    final habits = context.watch<HabitProvider>();
    final habit = habits.all.firstWhere((h) => h.id == habitId);
    final color = _habitColors[habit.colorIndex % _habitColors.length];

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: Text(habit.name),
        actions: [
          IconButton(
            onPressed: () {
              habits.delete(habit.id);
              Navigator.of(context).pop();
            },
            icon: const Icon(Icons.delete_outline_rounded, color: AppColors.dangerAccent),
          ),
        ],
      ),
      body: SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: GlassContainer(
                      child: Column(
                        children: [
                          Text('${habit.currentStreak}',
                              style: TextStyle(
                                  fontSize: 32,
                                  fontWeight: FontWeight.w800,
                                  color: color)),
                          const Text('current streak',
                              style: TextStyle(fontSize: 12, color: AppColors.textMuted)),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: GlassContainer(
                      child: Column(
                        children: [
                          Text('${habit.longestStreak}',
                              style: const TextStyle(
                                  fontSize: 32,
                                  fontWeight: FontWeight.w800,
                                  color: AppColors.textPrimary)),
                          const Text('best streak',
                              style: TextStyle(fontSize: 12, color: AppColors.textMuted)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              const Text('Last 12 weeks',
                  style: TextStyle(
                      color: AppColors.textPrimary,
                      fontWeight: FontWeight.w700,
                      fontSize: 15)),
              const SizedBox(height: 12),
              GlassContainer(child: _HeatmapGrid(habit: habit, color: color)),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: Material(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(16),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () => habits.toggleToday(habit.id),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        color: habit.isDoneToday ? null : AppColors.glassFillStrong,
                        gradient: habit.isDoneToday ? AppGradients.accent : null,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: AppColors.glassBorder),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        habit.isDoneToday ? 'Done today ✓' : 'Mark done for today',
                        style: const TextStyle(
                            color: Colors.white, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// GitHub-style contribution heatmap for the last ~84 days, built from
/// plain Containers (no chart dependency needed for this view).
class _HeatmapGrid extends StatelessWidget {
  const _HeatmapGrid({required this.habit, required this.color});
  final HabitItem habit;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final today = DateTime.now();
    final start = DateTime(today.year, today.month, today.day)
        .subtract(const Duration(days: 83));
    final weeks = <List<DateTime>>[];
    var cursor = start;
    // Align to start of week (Monday).
    cursor = cursor.subtract(Duration(days: cursor.weekday - 1));
    while (!cursor.isAfter(today)) {
      final week = List.generate(7, (i) => cursor.add(Duration(days: i)));
      weeks.add(week);
      cursor = cursor.add(const Duration(days: 7));
    }

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: weeks.map((week) {
          return Padding(
            padding: const EdgeInsets.only(right: 4),
            child: Column(
              children: week.map((d) {
                final inRange = !d.isAfter(today);
                final done = habit.isDoneOn(d);
                return Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Container(
                    width: 14,
                    height: 14,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(4),
                      color: !inRange
                          ? Colors.transparent
                          : done
                              ? color
                              : AppColors.glassFill,
                    ),
                  ),
                );
              }).toList(),
            ),
          );
        }).toList(),
      ),
    );
  }
}
