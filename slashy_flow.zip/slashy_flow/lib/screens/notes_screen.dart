import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../models/note_item.dart';
import '../providers/note_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_container.dart';

const _noteColors = [
  AppColors.glassFill,
  Color(0x337C6CFF),
  Color(0x3332D6C9),
  Color(0x33FFB35C),
  Color(0x33FF6B6B),
];

class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key});

  @override
  State<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final notes = context.watch<NoteProvider>();
    final list = notes.all(query: _query);

    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: AppGradients.accent,
          boxShadow: [
            BoxShadow(
                color: AppColors.accentB.withOpacity(0.35),
                blurRadius: 20,
                offset: const Offset(0, 8)),
          ],
        ),
        child: IconButton(
          icon: const Icon(Icons.add_rounded, color: Colors.white, size: 28),
          onPressed: () {
            final note = notes.create();
            _openEditor(context, note);
          },
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Notes',
                      style: TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.w800,
                          color: AppColors.textPrimary)),
                  const SizedBox(height: 12),
                  GlassContainer(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                    child: TextField(
                      onChanged: (v) => setState(() => _query = v),
                      style: const TextStyle(color: AppColors.textPrimary),
                      decoration: const InputDecoration(
                        border: InputBorder.none,
                        hintText: 'Search notes…',
                        hintStyle: TextStyle(color: AppColors.textMuted),
                        prefixIcon: Icon(Icons.search_rounded,
                            color: AppColors.textMuted, size: 20),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: list.isEmpty
                  ? const Center(
                      child: Text('No notes yet — tap + to write one.',
                          style: TextStyle(color: AppColors.textMuted)),
                    )
                  : MasonryGrid(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 120),
                      items: list,
                      onTap: (n) => _openEditor(context, n),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  void _openEditor(BuildContext context, NoteItem note) {
    Navigator.of(context).push(
      PageRouteBuilder(
        opaque: false,
        barrierColor: Colors.black54,
        pageBuilder: (_, __, ___) => NoteEditorScreen(noteId: note.id),
        transitionsBuilder: (_, anim, __, child) => FadeTransition(
          opacity: anim,
          child: child,
        ),
      ),
    );
  }
}

/// A simple two-column staggered grid (Pinterest-style) without extra deps.
class MasonryGrid extends StatelessWidget {
  const MasonryGrid({
    super.key,
    required this.items,
    required this.onTap,
    this.padding = EdgeInsets.zero,
  });

  final List<NoteItem> items;
  final ValueChanged<NoteItem> onTap;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    final left = <NoteItem>[];
    final right = <NoteItem>[];
    for (var i = 0; i < items.length; i++) {
      (i.isEven ? left : right).add(items[i]);
    }
    return SingleChildScrollView(
      padding: padding,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(child: Column(children: left.map((n) => _card(n)).toList())),
          const SizedBox(width: 12),
          Expanded(child: Column(children: right.map((n) => _card(n)).toList())),
        ],
      ),
    );
  }

  Widget _card(NoteItem n) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: GlassContainer(
        fillColor: _noteColors[n.colorTag % _noteColors.length],
        onTap: () => onTap(n),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                if (n.isPinned)
                  const Padding(
                    padding: EdgeInsets.only(right: 6),
                    child: Icon(Icons.push_pin_rounded,
                        size: 14, color: AppColors.textSecondary),
                  ),
                Expanded(
                  child: Text(
                    n.title.isEmpty ? 'Untitled' : n.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary),
                  ),
                ),
              ],
            ),
            if (n.body.isNotEmpty) ...[
              const SizedBox(height: 6),
              Text(
                n.body,
                maxLines: 5,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    fontSize: 13, color: AppColors.textSecondary, height: 1.3),
              ),
            ],
            const SizedBox(height: 8),
            Text(
              DateFormat('MMM d, HH:mm').format(n.updatedAt),
              style: const TextStyle(fontSize: 10, color: AppColors.textMuted),
            ),
          ],
        ),
      ),
    );
  }
}

class NoteEditorScreen extends StatefulWidget {
  const NoteEditorScreen({super.key, required this.noteId});
  final String noteId;

  @override
  State<NoteEditorScreen> createState() => _NoteEditorScreenState();
}

class _NoteEditorScreenState extends State<NoteEditorScreen> {
  late TextEditingController _title;
  late TextEditingController _body;
  late NoteItem _note;

  @override
  void initState() {
    super.initState();
    final notes = context.read<NoteProvider>();
    _note = notes.all().firstWhere((n) => n.id == widget.noteId);
    _title = TextEditingController(text: _note.title);
    _body = TextEditingController(text: _note.body);
  }

  void _persist() {
    final notes = context.read<NoteProvider>();
    notes.save(_note.copyWith(title: _title.text, body: _body.text));
  }

  @override
  void dispose() {
    _persist();
    _title.dispose();
    _body.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final notes = context.watch<NoteProvider>();
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: GlassContainer(
            fillColor: _noteColors[_note.colorTag % _noteColors.length],
            blurSigma: 30,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    IconButton(
                      onPressed: () => Navigator.of(context).pop(),
                      icon: const Icon(Icons.arrow_back_rounded,
                          color: AppColors.textPrimary),
                    ),
                    const Spacer(),
                    IconButton(
                      onPressed: () {
                        notes.togglePin(_note.id);
                        setState(() => _note = _note.copyWith(isPinned: !_note.isPinned));
                      },
                      icon: Icon(
                        _note.isPinned
                            ? Icons.push_pin_rounded
                            : Icons.push_pin_outlined,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    IconButton(
                      onPressed: () {
                        notes.delete(_note.id);
                        Navigator.of(context).pop();
                      },
                      icon: const Icon(Icons.delete_outline_rounded,
                          color: AppColors.dangerAccent),
                    ),
                  ],
                ),
                Row(
                  children: List.generate(_noteColors.length, (i) {
                    final selected = _note.colorTag == i;
                    return GestureDetector(
                      onTap: () {
                        setState(() => _note = _note.copyWith(colorTag: i));
                        notes.save(_note);
                      },
                      child: Container(
                        margin: const EdgeInsets.only(right: 10),
                        width: 26,
                        height: 26,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: i == 0
                              ? AppColors.bgBottom
                              : _noteColors[i].withOpacity(1),
                          border: Border.all(
                            color: selected
                                ? Colors.white
                                : AppColors.glassBorder,
                            width: selected ? 2 : 1,
                          ),
                        ),
                      ),
                    );
                  }),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _title,
                  style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                      color: AppColors.textPrimary),
                  decoration: const InputDecoration(
                    hintText: 'Title',
                    hintStyle: TextStyle(color: AppColors.textMuted),
                    border: InputBorder.none,
                  ),
                ),
                Expanded(
                  child: TextField(
                    controller: _body,
                    maxLines: null,
                    expands: true,
                    textAlignVertical: TextAlignVertical.top,
                    style: const TextStyle(
                        color: AppColors.textSecondary, height: 1.5),
                    decoration: const InputDecoration(
                      hintText: 'Start writing…',
                      hintStyle: TextStyle(color: AppColors.textMuted),
                      border: InputBorder.none,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
