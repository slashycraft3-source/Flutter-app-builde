import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../models/todo_item.dart';
import '../providers/todo_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_container.dart';

class TodoScreen extends StatefulWidget {
  const TodoScreen({super.key});

  @override
  State<TodoScreen> createState() => _TodoScreenState();
}

enum _Filter { active, done, all }

class _TodoScreenState extends State<TodoScreen> {
  _Filter _filter = _Filter.active;

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TodoProvider>();
    final items = switch (_filter) {
      _Filter.active => provider.pending,
      _Filter.done => provider.completed,
      _Filter.all => provider.all,
    };

    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: _AddButton(onPressed: () => _openEditor(context)),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
              child: Row(
                children: [
                  const Text('Tasks',
                      style: TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.w800,
                          color: AppColors.textPrimary)),
                  const Spacer(),
                  Text('${provider.pending.length} open',
                      style: const TextStyle(color: AppColors.textMuted)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  GlassChip(
                    label: 'Active',
                    selected: _filter == _Filter.active,
                    color: AppColors.todoAccent,
                    onTap: () => setState(() => _filter = _Filter.active),
                  ),
                  const SizedBox(width: 8),
                  GlassChip(
                    label: 'Done',
                    selected: _filter == _Filter.done,
                    color: AppColors.todoAccent,
                    onTap: () => setState(() => _filter = _Filter.done),
                  ),
                  const SizedBox(width: 8),
                  GlassChip(
                    label: 'All',
                    selected: _filter == _Filter.all,
                    color: AppColors.todoAccent,
                    onTap: () => setState(() => _filter = _Filter.all),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: items.isEmpty
                  ? Center(
                      child: Text(
                        _filter == _Filter.done
                            ? 'No completed tasks yet.'
                            : 'Nothing here — tap + to add a task.',
                        style: const TextStyle(color: AppColors.textMuted),
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 120),
                      itemCount: items.length,
                      itemBuilder: (context, i) =>
                          _TodoTile(item: items[i], onEdit: () => _openEditor(context, item: items[i])),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  void _openEditor(BuildContext context, {TodoItem? item}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _TodoEditorSheet(existing: item),
    );
  }
}

class _AddButton extends StatelessWidget {
  const _AddButton({required this.onPressed});
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: AppGradients.accent,
        boxShadow: [
          BoxShadow(
              color: AppColors.accentA.withOpacity(0.4),
              blurRadius: 20,
              offset: const Offset(0, 8)),
        ],
      ),
      child: IconButton(
        onPressed: onPressed,
        icon: const Icon(Icons.add_rounded, color: Colors.white, size: 28),
      ),
    );
  }
}

class _TodoTile extends StatelessWidget {
  const _TodoTile({required this.item, required this.onEdit});
  final TodoItem item;
  final VoidCallback onEdit;

  Color _priorityColor() {
    switch (item.priority) {
      case Priority.high:
        return AppColors.dangerAccent;
      case Priority.medium:
        return AppColors.habitAccent;
      case Priority.low:
        return AppColors.noteAccent;
    }
  }

  @override
  Widget build(BuildContext context) {
    final todos = context.read<TodoProvider>();
    return Slidable(
      key: ValueKey(item.id),
      endActionPane: ActionPane(
        motion: const DrawerMotion(),
        extentRatio: 0.25,
        children: [
          SlidableAction(
            onPressed: (_) => todos.delete(item.id),
            backgroundColor: Colors.transparent,
            foregroundColor: AppColors.dangerAccent,
            icon: Icons.delete_rounded,
            borderRadius: BorderRadius.circular(AppRadii.card),
          ),
        ],
      ),
      child: GlassContainer(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        onTap: onEdit,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            GestureDetector(
              onTap: () => todos.toggleDone(item.id),
              child: Container(
                width: 24,
                height: 24,
                margin: const EdgeInsets.only(top: 2),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: item.isDone
                      ? AppColors.todoAccent
                      : Colors.transparent,
                  border: Border.all(
                    color: item.isDone
                        ? AppColors.todoAccent
                        : AppColors.glassBorder,
                    width: 2,
                  ),
                ),
                child: item.isDone
                    ? const Icon(Icons.check, size: 16, color: Colors.white)
                    : null,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.title,
                    style: TextStyle(
                      color: item.isDone
                          ? AppColors.textMuted
                          : AppColors.textPrimary,
                      fontWeight: FontWeight.w600,
                      decoration:
                          item.isDone ? TextDecoration.lineThrough : null,
                    ),
                  ),
                  if (item.notes.isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Text(item.notes,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            color: AppColors.textMuted, fontSize: 12)),
                  ],
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Container(
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle, color: _priorityColor()),
                      ),
                      const SizedBox(width: 6),
                      Text(item.tag,
                          style: const TextStyle(
                              fontSize: 11, color: AppColors.textMuted)),
                      if (item.dueDate != null) ...[
                        const SizedBox(width: 10),
                        Icon(Icons.event_rounded,
                            size: 12,
                            color: item.isOverdue
                                ? AppColors.dangerAccent
                                : AppColors.textMuted),
                        const SizedBox(width: 3),
                        Text(
                          DateFormat('MMM d').format(item.dueDate!),
                          style: TextStyle(
                              fontSize: 11,
                              color: item.isOverdue
                                  ? AppColors.dangerAccent
                                  : AppColors.textMuted),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TodoEditorSheet extends StatefulWidget {
  const _TodoEditorSheet({this.existing});
  final TodoItem? existing;

  @override
  State<_TodoEditorSheet> createState() => _TodoEditorSheetState();
}

class _TodoEditorSheetState extends State<_TodoEditorSheet> {
  late final TextEditingController _title;
  late final TextEditingController _notes;
  late final TextEditingController _tag;
  late Priority _priority;
  DateTime? _dueDate;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _title = TextEditingController(text: e?.title ?? '');
    _notes = TextEditingController(text: e?.notes ?? '');
    _tag = TextEditingController(text: e?.tag ?? 'General');
    _priority = e?.priority ?? Priority.medium;
    _dueDate = e?.dueDate;
  }

  @override
  void dispose() {
    _title.dispose();
    _notes.dispose();
    _tag.dispose();
    super.dispose();
  }

  void _save() {
    if (_title.text.trim().isEmpty) return;
    final todos = context.read<TodoProvider>();
    if (widget.existing == null) {
      todos.add(
        title: _title.text.trim(),
        notes: _notes.text.trim(),
        priority: _priority,
        dueDate: _dueDate,
        tag: _tag.text.trim().isEmpty ? 'General' : _tag.text.trim(),
      );
    } else {
      todos.update(widget.existing!.copyWith(
        title: _title.text.trim(),
        notes: _notes.text.trim(),
        priority: _priority,
        dueDate: _dueDate,
        clearDueDate: _dueDate == null,
        tag: _tag.text.trim().isEmpty ? 'General' : _tag.text.trim(),
      ));
    }
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
        child: GlassContainer(
          borderRadius: AppRadii.sheet,
          blurSigma: 30,
          fillColor: AppColors.glassFillStrong,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                        color: AppColors.textMuted,
                        borderRadius: BorderRadius.circular(4)),
                  ),
                ),
                Text(
                  widget.existing == null ? 'New task' : 'Edit task',
                  style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary),
                ),
                const SizedBox(height: 16),
                _field(_title, 'What needs doing?', autofocus: true),
                const SizedBox(height: 10),
                _field(_notes, 'Notes (optional)', maxLines: 2),
                const SizedBox(height: 10),
                _field(_tag, 'Tag (e.g. Work, Personal)'),
                const SizedBox(height: 16),
                const Text('Priority',
                    style: TextStyle(
                        color: AppColors.textSecondary,
                        fontWeight: FontWeight.w600,
                        fontSize: 12)),
                const SizedBox(height: 8),
                Row(
                  children: Priority.values.map((p) {
                    final selected = _priority == p;
                    return Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: GlassChip(
                        label: p.name,
                        selected: selected,
                        color: p == Priority.high
                            ? AppColors.dangerAccent
                            : p == Priority.medium
                                ? AppColors.habitAccent
                                : AppColors.noteAccent,
                        onTap: () => setState(() => _priority = p),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: GlassChip(
                        icon: Icons.event_rounded,
                        label: _dueDate == null
                            ? 'Set due date'
                            : DateFormat('MMM d, yyyy').format(_dueDate!),
                        selected: _dueDate != null,
                        color: AppColors.todoAccent,
                        onTap: () async {
                          final picked = await showDatePicker(
                            context: context,
                            initialDate: _dueDate ?? DateTime.now(),
                            firstDate: DateTime.now()
                                .subtract(const Duration(days: 365)),
                            lastDate:
                                DateTime.now().add(const Duration(days: 3650)),
                          );
                          if (picked != null) setState(() => _dueDate = picked);
                        },
                      ),
                    ),
                    if (_dueDate != null) ...[
                      const SizedBox(width: 8),
                      IconButton(
                        onPressed: () => setState(() => _dueDate = null),
                        icon: const Icon(Icons.close_rounded,
                            color: AppColors.textMuted),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: _GradientButton(
                    label: widget.existing == null ? 'Add task' : 'Save changes',
                    onPressed: _save,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _field(TextEditingController c, String hint,
      {bool autofocus = false, int maxLines = 1}) {
    return TextField(
      controller: c,
      autofocus: autofocus,
      maxLines: maxLines,
      style: const TextStyle(color: AppColors.textPrimary),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: AppColors.textMuted),
        filled: true,
        fillColor: AppColors.glassFill,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }
}

class _GradientButton extends StatelessWidget {
  const _GradientButton({required this.label, required this.onPressed});
  final String label;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onPressed,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            gradient: AppGradients.accent,
            borderRadius: BorderRadius.circular(16),
          ),
          alignment: Alignment.center,
          child: Text(label,
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.w700)),
        ),
      ),
    );
  }
}
