import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../providers/todo_provider.dart';
import '../providers/note_provider.dart';
import '../providers/habit_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_container.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  String _greeting() {
    final h = DateTime.now().hour;
    if (h < 5) return 'Still up?';
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    if (h < 21) return 'Good evening';
    return 'Late night grind';
  }

  @override
  Widget build(BuildContext context) {
    final todos = context.watch<TodoProvider>();
    final notes = context.watch<NoteProvider>();
    final habits = context.watch<HabitProvider>();
    final dateStr = DateFormat('EEEE, MMMM d').format(DateTime.now());

    return CustomScrollView(
      physics: const BouncingScrollPhysics(),
      slivers: [
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
          sliver: SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(dateStr,
                    style: const TextStyle(
                        color: AppColors.textMuted,
                        fontWeight: FontWeight.w600,
                        fontSize: 13)),
                const SizedBox(height: 4),
                Text(_greeting(),
                    style: const TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary)),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: _StatCard(
                        icon: Icons.check_circle_rounded,
                        color: AppColors.todoAccent,
                        value: '${todos.completedTodayCount}',
                        label: 'Done today',
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _StatCard(
                        icon: Icons.local_fire_department_rounded,
                        color: AppColors.habitAccent,
                        value: '${habits.bestActiveStreak}',
                        label: 'Best streak',
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _StatCard(
                        icon: Icons.sticky_note_2_rounded,
                        color: AppColors.noteAccent,
                        value: '${notes.count}',
                        label: 'Notes',
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                if (todos.overdueCount > 0)
                  GlassContainer(
                    fillColor: AppColors.dangerAccent.withOpacity(0.12),
                    borderColor: AppColors.dangerAccent.withOpacity(0.4),
                    margin: const EdgeInsets.only(bottom: 16),
                    child: Row(
                      children: [
                        const Icon(Icons.warning_rounded,
                            color: AppColors.dangerAccent, size: 20),
                        const SizedBox(width: 10),
                        Text(
                          '${todos.overdueCount} overdue task${todos.overdueCount == 1 ? '' : 's'}',
                          style: const TextStyle(
                              color: AppColors.textPrimary,
                              fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  ),
                const Text('Up next',
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary)),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
        if (todos.pending.isEmpty)
          const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: _EmptyRow(text: "Nothing pending — you're all caught up."),
            ),
          )
        else
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            sliver: SliverList.builder(
              itemCount: todos.pending.take(5).length,
              itemBuilder: (context, i) {
                final t = todos.pending[i];
                return GlassContainer(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  onTap: () => todos.toggleDone(t.id),
                  child: Row(
                    children: [
                      Icon(Icons.radio_button_unchecked,
                          color: AppColors.textMuted, size: 20),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(t.title,
                            style: const TextStyle(
                                color: AppColors.textPrimary,
                                fontWeight: FontWeight.w600)),
                      ),
                      if (t.dueDate != null)
                        Text(
                          DateFormat('MMM d').format(t.dueDate!),
                          style: TextStyle(
                            color: t.isOverdue
                                ? AppColors.dangerAccent
                                : AppColors.textMuted,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                    ],
                  ),
                );
              },
            ),
          ),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
          sliver: SliverToBoxAdapter(
            child: Text('Habits today',
                style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary)),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.all(20),
          sliver: habits.all.isEmpty
              ? const SliverToBoxAdapter(
                  child: _EmptyRow(text: 'No habits yet — add one on the Habits tab.'))
              : SliverToBoxAdapter(
                  child: SizedBox(
                    height: 96,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: habits.all.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 12),
                      itemBuilder: (context, i) {
                        final h = habits.all[i];
                        return GestureDetector(
                          onTap: () => habits.toggleToday(h.id),
                          child: GlassContainer(
                            width: 96,
                            fillColor: h.isDoneToday
                                ? AppColors.habitAccent.withOpacity(0.2)
                                : null,
                            borderColor: h.isDoneToday
                                ? AppColors.habitAccent.withOpacity(0.6)
                                : null,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  h.isDoneToday
                                      ? Icons.local_fire_department_rounded
                                      : Icons.local_fire_department_outlined,
                                  color: h.isDoneToday
                                      ? AppColors.habitAccent
                                      : AppColors.textMuted,
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  h.name,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w700,
                                      color: AppColors.textPrimary),
                                ),
                                Text('${h.currentStreak}d streak',
                                    style: const TextStyle(
                                        fontSize: 10,
                                        color: AppColors.textMuted)),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
        ),
        const SliverPadding(padding: EdgeInsets.only(bottom: 110)),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({
    required this.icon,
    required this.color,
    required this.value,
    required this.label,
  });

  final IconData icon;
  final Color color;
  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return GlassContainer(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
      child: Column(
        children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(height: 8),
          Text(value,
              style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: AppColors.textPrimary)),
          const SizedBox(height: 2),
          Text(label,
              style: const TextStyle(fontSize: 11, color: AppColors.textMuted)),
        ],
      ),
    );
  }
}

class _EmptyRow extends StatelessWidget {
  const _EmptyRow({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    return GlassContainer(
      child: Text(text,
          style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
    );
  }
}
