# Slashy Flow

A Todo + Notes + Habit Tracker app for Android, built in Flutter with a dark,
frosted-glass ("glassmorphism") design: blurred translucent cards floating
over a slow-drifting gradient background.

## What's inside

- **Todo** — add/edit/delete, priority (low/med/high), due dates, tags,
  active/done/all filters, swipe-to-delete, overdue warnings.
- **Notes** — Pinterest-style masonry grid, search, pin-to-top, 5 color
  tags, full-screen editor.
- **Habits** — daily check-in, real streak math (current + longest), a
  7-day strip per habit, and a GitHub-style 12-week heatmap on the habit
  detail screen.
- **Home dashboard** — greeting, quick stats (done today / best streak /
  note count), overdue banner, upcoming tasks, and a horizontal habit
  strip.
- Everything persists locally on-device via **Hive** — no backend, no
  account, works offline. No analytics, no ads.

## Why there's no `android/` or `ios/` folder yet

Flutter's platform folders (Gradle files, `AndroidManifest.xml`, Xcode
project, etc.) are version-pinned to *your* installed Flutter SDK, and
generating them correctly requires actually running the `flutter` CLI —
which isn't available in the environment this was written in. Rather than
hand-write Gradle files that might not match your SDK version and quietly
fail to build, do this instead (takes ~30 seconds):

```bash
# 1. Scaffold a fresh Flutter project (this generates android/, ios/, etc.)
flutter create slashy_flow_app
cd slashy_flow_app

# 2. Replace the generated lib/ and pubspec.yaml with the ones from this project
rm -rf lib
cp -r ../slashy_flow/lib .
cp ../slashy_flow/pubspec.yaml .

# 3. Install dependencies
flutter pub get

# 4. Run it (device or emulator connected)
flutter run

# 5. When you're ready for a real Android build:
flutter build apk --release
# output: build/app/outputs/flutter-apk/app-release.apk
```

If you're on Android Studio, you can instead create a new Flutter project
through the UI, then drag `lib/` and `pubspec.yaml` in the same way.

## Project structure

```
lib/
  main.dart                 # entry point, Hive init, providers
  theme/app_theme.dart      # colors, gradients, ThemeData
  models/                   # TodoItem, NoteItem, HabitItem + Hive adapters
  providers/                # ChangeNotifier state classes per feature
  widgets/
    glass_container.dart    # the core frosted-glass panel + chip widgets
    animated_background.dart# drifting blurred color orbs behind everything
  screens/
    home_shell.dart          # bottom nav + glass nav bar
    dashboard_screen.dart
    todo_screen.dart
    notes_screen.dart
    habits_screen.dart
```

## Notes on the design choices

- Hive adapters are **hand-written** (see the bottom of each model file)
  instead of code-generated, so there's no `build_runner` step — it just
  works after `pub get`.
- `GlassContainer` (in `widgets/glass_container.dart`) is the one widget
  every card in the app is built from. Tweak `blurSigma`, `fillColor`, or
  `borderColor` there to change the glass effect app-wide.
- The background orbs in `animated_background.dart` are intentionally
  subtle — they're what the glass blur "sees," so turning their opacity up
  makes the frosted effect much more colorful if you want a punchier look.

## Realistic next steps (not included, to keep this a working v1)

- Notifications/reminders for tasks and habit check-ins
- Cloud sync / multi-device (would need a backend — Firebase is the
  fastest path with Hive already in place)
- Rich text in notes (currently plain text)
- Widgets/home-screen shortcuts
